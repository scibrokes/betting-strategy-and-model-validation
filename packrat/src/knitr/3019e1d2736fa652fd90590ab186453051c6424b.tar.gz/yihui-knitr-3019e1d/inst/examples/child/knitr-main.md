You can also use the `child` option to include child documents in markdown.


Hi, there. I'm a child.


```r
options(digits = 4)
1 + 1
```

```
## [1] 2
```

```r
dnorm(0)
```

```
## [1] 0.3989
```

You can continue your main document below, of course.


```r
pmax(1:10, 5)
```

```
##  [1]  5  5  5  5  5  6  7  8  9 10
```
