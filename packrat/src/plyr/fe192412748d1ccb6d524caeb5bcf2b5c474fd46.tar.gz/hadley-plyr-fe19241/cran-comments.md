## Test environments
* local OS X install, R 3.3.0
* ubuntu 12.04 (on travis-ci), R 3.3.0
* win-builder (devel and release)

## R CMD check results

0 errors | 0 warnings | 1 note

* This package uses the MIT license.

## Reverse dependencies

I did not run the reverse dependencies since the only changes in this version were to fix minor R CMD check problems, and the prevent one of the tests from failing in R-devel (patch helpful provided by Martin Maechler.)
