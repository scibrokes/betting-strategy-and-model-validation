#' @section Output: If there are no results, then this function will return
#'   a list of length 0 (\code{list()}).
#'
#' @return list of results
#' @family list output
