#' @family list input
#' @section Input: This function splits lists by elements.
#'
#' @param .data list to be processed
