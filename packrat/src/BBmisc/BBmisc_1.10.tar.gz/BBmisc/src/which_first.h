#ifndef BBMISC_WHICH_FIRST_H_
#define BBMISC_WHICH_FIRST_H_

#include <R.h>
#include <Rinternals.h>
#include <Rdefines.h>

SEXP c_which_first(SEXP, SEXP);
SEXP c_which_last(SEXP, SEXP);

#endif
