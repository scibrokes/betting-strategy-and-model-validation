# backports 1.0.3

* Removed stringi dependency

# backports 1.0.2

* Fixed `file.size()`, `file.mtime()` and `file.mode()` for R-3.1.x.

# backports 1.0.1

* Added `file.size()`, `file.mtime()` and `file.mode()` (introduced in R-3.2.0).

# backports 1.0.0

* Initial version.
